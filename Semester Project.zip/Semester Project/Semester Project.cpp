#include <iostream>
#include <cmath>

using namespace std;

int main() {
    double num1, num2;
    char op;

    cout << "Enter first number: ";
    cin >> num1;

    cout << "Enter an operator (+, -, *, /): ";
    cin >> op;

    if (op != '+' && op != '-' && op != '*' && op != '/') {
        cout << "Invalid operator!";
        return 0;
    }

    cout << "Enter second number: ";
    cin >> num2;

    switch(op) {
        case '+':
            cout << "Result: " << num1 + num2;
            break;
        case '-':
            cout << "Result: " << num1 - num2;
            break;
        case '*':
            cout << "Result: " << num1 * num2;
            break;
        case '/':
            if (num2 != 0)
                cout << "Result: " << num1 / num2;
            else
                cout << "Cannot divide by zero!";
            break;
    }

    cout << endl;

    // Additional scientific functions
    char choice;
    cout << "Do you want to perform any scientific functions? (y/n): ";
    cin >> choice;

    if (choice == 'y' || choice == 'Y') {
        double result;
        int sciFunc;

        cout << "Select a scientific function:" << endl;
        cout << "1. Square Root" << endl;
        cout << "2. Exponentiation" << endl;
        cin >> sciFunc;

        switch(sciFunc) {
            case 1:
                result = sqrt(num1);
                cout << "Square Root of " << num1 << " is " << result;
                break;
            case 2:
                result = pow(num1, num2);
                cout << num1 << " raised to the power of " << num2 << " is " << result;
                break;
            default:
                cout << "Invalid choice!";
                break;
        }
    }

    return 0;
}


